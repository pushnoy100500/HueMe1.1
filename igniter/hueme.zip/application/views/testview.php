<?php
//header("Content-Type: application/x-www-form-urlencoded");
//header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

echo json_encode($data);